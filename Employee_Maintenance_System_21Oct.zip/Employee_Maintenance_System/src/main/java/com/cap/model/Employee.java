package com.cap.model;

import java.time.LocalDate;

public class Employee {

	private String empId;
	
	private String empFirstName;
	
	private String empLastName;
	
	private LocalDate empDateOfBirth;
	
	private LocalDate empDateOfJoining;
	
	private int empDeptId;
	
	private String empGrade;
	
	private String empDesignation;
	
	private int empBasic;
	
	private String empGender;
	
	private String empMaritalStaus;
	
	private String empHomeAddress;
	
	private String empContactNumber;
	

	public Employee(String empId, String empFirstName, String empLastName, LocalDate empDateOfBirth,
			LocalDate empDateOfJoining, int empDeptId, String empGrade, String empDesignation, int empBasic,
			String empGender, String empMaritalStaus, String empHomeAddress, String empContactNumber) {
		super();
		this.empId = empId;
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.empDateOfBirth = empDateOfBirth;
		this.empDateOfJoining = empDateOfJoining;
		this.empDeptId = empDeptId;
		this.empGrade = empGrade;
		this.empDesignation = empDesignation;
		this.empBasic = empBasic;
		this.empGender = empGender;
		this.empMaritalStaus = empMaritalStaus;
		this.empHomeAddress = empHomeAddress;
		this.empContactNumber = empContactNumber;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpFirstName() {
		return empFirstName;
	}

	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}

	public String getEmpLastName() {
		return empLastName;
	}

	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}

	public LocalDate getEmpDateOfBirth() {
		return empDateOfBirth;
	}

	public void setEmpDateOfBirth(LocalDate empDateOfBirth) {
		this.empDateOfBirth = empDateOfBirth;
	}

	public LocalDate getEmpDateOfJoining() {
		return empDateOfJoining;
	}

	public void setEmpDateOfJoining(LocalDate empDateOfJoining) {
		this.empDateOfJoining = empDateOfJoining;
	}

	public int getEmpDeptId() {
		return empDeptId;
	}

	public void setEmpDeptId(int empDeptId) {
		this.empDeptId = empDeptId;
	}

	public String getEmpGrade() {
		return empGrade;
	}

	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}

	public String getEmpDesignation() {
		return empDesignation;
	}

	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}

	public int getEmpBasic() {
		return empBasic;
	}

	public void setEmpBasic(int empBasic) {
		this.empBasic = empBasic;
	}

	public String getEmpGender() {
		return empGender;
	}

	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}

	public String getEmpMaritalStaus() {
		return empMaritalStaus;
	}

	public void setEmpMaritalStaus(String empMaritalStaus) {
		this.empMaritalStaus = empMaritalStaus;
	}

	public String getEmpHomeAddress() {
		return empHomeAddress;
	}

	public void setEmpHomeAddress(String empHomeAddress) {
		this.empHomeAddress = empHomeAddress;
	}

	public String getEmpContactNumber() {
		return empContactNumber;
	}

	public void setEmpContactNumber(String empContactNumber) {
		this.empContactNumber = empContactNumber;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empFirstName=" + empFirstName + ", empLastName=" + empLastName
				+ ", empDateOfBirth=" + empDateOfBirth + ", empDateOfJoining=" + empDateOfJoining + ", empDeptId="
				+ empDeptId + ", empGrade=" + empGrade + ", empDesignation=" + empDesignation + ", empBasic=" + empBasic
				+ ", empGender=" + empGender + ", empMaritalStaus=" + empMaritalStaus + ", empHomeAddress="
				+ empHomeAddress + ", empContactNumber=" + empContactNumber + "]";
	}

	public Employee() {
		super();
	}
	
	
	
	 
	
	
}
