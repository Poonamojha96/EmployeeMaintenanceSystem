package com.cap.view;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Scanner;

import com.cap.model.Employee;
import com.cap.service.EmployeeServiceImpl;
import com.cap.service.IEmployeeService;

public class UserInteraction {

	Scanner scan= new Scanner(System.in);
	
	public Employee addEmployeeDetails()
	{
		Employee employee = new Employee();
		
		employee.setEmpId(promptEmployeeId());
		employee.setEmpFirstName(promptFirstName());
		employee.setEmpLastName(promptLastName());
		LocalDate dateOfBirth=promptDateOfBirth();
		employee.setEmpDateOfBirth(dateOfBirth);
		LocalDate dateOfJoining=promptDateOfJoining();
		employee.setEmpDateOfJoining(dateOfJoining);
		
		//Department Name  
		//employee.setEmpDeptId(promptDepartmentId());
		
		employee.setEmpGrade(promptGrade());
		employee.setEmpDesignation(promptDesignation());
		employee.setEmpGender(promptGender());
		//Employee Basic
		//employee.setEmpBasic(empBasic);
		employee.setEmpMaritalStaus(promptMaritalStatus());
		employee.setEmpHomeAddress(promptHomeAddress());
		employee.setEmpContactNumber(promptContactNumber());
		
		return employee;
		
	}

	private String promptContactNumber() {
		boolean flag=false;
		String contactNo;
		
			System.out.println("Enter Home Address");
			contactNo=scan.next();
			flag=Utility.isValidContactNumber(contactNo);
			if(flag)
				return contactNo;
			return contactNo;
	}

	private String promptHomeAddress() {
		boolean flag=false;
		String address;
		
			System.out.println("Enter Home Address");
			address=scan.next();
			flag=Utility.isValidHomeAddress(address);
			if(flag)
				return address;
			return address;
				
	
	}

	private String promptMaritalStatus() {
		int choice=0;
		System.out.println("Enter the Marital Status[1-5]:\n1. Single\n2/ Married\n3."
				+ "Divorced\n4. Separated\n5. Widowed");
		choice=scan.nextInt();
		do {
		switch(choice)
		{
		case 1:
			return "Single";
		case 2:
			return "Married";
		case 3:
			return "Divorced";
		case 4:
			return "Separated";
		case 5:
			return "Widowed";
		default:
			System.out.println("Enter valid choice for marital status!!");
			choice=scan.nextInt();
		}
			
		}while(true);
	}

	private String promptGender() {
		int choice=0;
		System.out.println("Enter the Gender[1/2]:\n1. Male\n2/ Female");
		choice=scan.nextInt();
		do {
		switch(choice)
		{
		case 1:
			return "Male";
		case 2:
			return "Female";
		default:
			System.out.println("Enter valid choice for gender!!");
			choice=scan.nextInt();
		}
			
		}while(true);
		
	}

	private String promptDesignation() {
		boolean flag=false;
		String design;
		do {
			System.out.println("Enter Designation");
			design=scan.next();
			flag=Utility.isValidDesignation(design);
			if(!flag)
				System.out.println("Enter a valid Designation");
	
		}while(!flag);
		
		return design;
	}

	private String promptGrade() {
		
		System.out.println("Choose from below[1-7]:\n1. M1\n2. M2\n3. M3\n4. M4\n5."
				+ "M5\n6. M6\n7.M7");
		int choice = scan.nextInt();
		do {
		switch(choice)
		{
		case 1:
			return "M1";
			
		case 2:
			return "M2";
			
		case 3:
			return "M3";
			
		case 4:
			return "M4";
			
		case 5:
			return "M5";
			
		case 6:
			return "M6";
			
		case 7:
			return "M7";
			
		default: 
			System.out.println("Invalid choice!! Please enter a valid choice.");
			choice = scan.nextInt();

		} 
		}while(true);
	}

	private int promptDepartmentId() {
		
		IEmployeeService employeeService= new EmployeeServiceImpl();
		
		return 0;
	}

	private LocalDate promptDateOfJoining() {

		boolean flag=false;
		
		DateTimeFormatter dTF = 
			    new DateTimeFormatterBuilder().parseCaseInsensitive()
			                                  .appendPattern("dd-MMM-yyyy")
			                                  .toFormatter();
		String doj;
		do {
			System.out.println("Enter date of birth[DD-MMM-YY]");
			doj=scan.next();
			
			flag=Utility.isValidDateOfBirth(doj);
			
			if(!flag)
				System.out.println("Enter a valid date of birth[DD-MMM-YY]");
	
		}while(!flag);
		LocalDate ld = LocalDate.parse(doj,dTF);
		
		return ld; 
		
	}

	private LocalDate promptDateOfBirth() {
		
		boolean flag=false;
		
		DateTimeFormatter dTF = 
			    new DateTimeFormatterBuilder().parseCaseInsensitive()
			                                  .appendPattern("dd-MMM-yyyy")
			                                  .toFormatter();
		String dob;
		do {
			System.out.println("Enter date of birth[DD-MMM-YY]");
			dob=scan.next();
			
			flag=Utility.isValidDateOfBirth(dob);
			
			if(!flag)
				System.out.println("Enter a valid date of birth[DD-MMM-YY]");
	
		}while(!flag);
		LocalDate ld = LocalDate.parse(dob,dTF);
		
		return ld; 
	}

	private String promptLastName() {
		boolean flag=false;
		String lname;
		do {
			System.out.println("Enter last name");
			 lname=scan.next();
			flag=Utility.isValidLastName(lname);
			if(!flag)
				System.out.println("Enter a valid last name");
	
		}while(!flag);
		
		return lname;
	}

	private String promptFirstName() {
		
		boolean flag=false;
		String fname;
		do {
			System.out.println("Enter first name");
			 fname=scan.next();
			flag=Utility.isValidFirstName(fname);
			if(!flag)
				System.out.println("Enter a valid first name");
	
		}while(!flag);
		
		return fname;
	}

	private String promptEmployeeId() {
		
		boolean flag=false;
		String empId;
		do {
			System.out.println("Enter Employee ID");
			empId=scan.next();
			flag=Utility.isValidEmpId(empId);
			if(!flag)
				System.out.println("Enter a valid Employee ID");
	
		}while(!flag);
		
		return empId;
	}
	
}
