package com.cap.DAO;

public interface IEmployeeDAO {

}
