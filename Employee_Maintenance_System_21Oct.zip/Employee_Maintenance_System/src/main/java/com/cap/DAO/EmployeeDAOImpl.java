package com.cap.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cap.model.Employee;
import com.cap.model.Grade_master;
import com.cap.model.User_master;

public class EmployeeDAOImpl implements IEmployeeDAO {
	
	public void add_employee_Details(Employee emp)
	{
		
		String sql1="insert into employee(emp_Id ,emp_First_Name ,emp_Last_Name,"
				+ "emp_Date_Of_Birth ,Emp_Date_Of_Joining ,Emp_dept_id,Emp_Grade "
				+ "Emp_designation ,Emp_Basic,Emp_Gender,Emp_Marital_status "
				+ "Emp_home_Address ,Emp_contact_Num )"
				+ "  into values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql1))
		{
			pst.setString(1,emp.getEmpId());
			pst.setString(2, emp.getEmpFirstName());
			pst.setString(3, emp.getEmpLastName());
			pst.setDate(4, Date.valueOf(emp.getEmpDateOfBirth()));
			pst.setDate(5,Date.valueOf(emp.getEmpDateOfJoining()));
			pst.setInt(6,emp.getEmpDeptId());
			pst.setString(7, emp.getEmpGrade());
			pst.setString(8, emp.getEmpDesignation());
			pst.setInt(9, emp.getEmpBasic());
			pst.setString(10,emp.getEmpGender());
			pst.setString(12,emp.getEmpHomeAddress());
			pst.setString(11,emp.getEmpMaritalStaus());
			pst.setString(13,emp.getEmpContactNumber());
			
			int c=pst.executeUpdate();
			
			if(c>0)
			{
				System.out.println("Record Inserted");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void add_user_master(User_master master)
	{
		String sql2="insert into user_master(userId,userName,userPassword ,userType)"
				+ "  into values(?,?,?,?)";
		try(PreparedStatement pst1=getMysqlDbConnection().prepareStatement(sql2))
		{
			pst1.setString(1,master.getUserId());
			pst1.setString(2, master.getUserName());
			pst1.setString(3, master.getUserPassword());
			pst1.setString(4, master.getUserType());
			
      int c1=pst1.executeUpdate();
			
			if(c1>0)
			{
				System.out.println("Record Inserted");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void add_Grade_Master(Grade_master grade)
	{
		String sql3="insert into Grade_master(Grade_code,Description,Min_Salary,Max_salary )"
				+ "  into values(?,?,?,?)";
		try(PreparedStatement pst2=getMysqlDbConnection().prepareStatement(sql3))
		{
			pst2.setString(1,grade.getGradeCode());
			pst2.setString(2, grade.getDescription());
			pst2.setInt(3, grade.getMinSalary());
			pst2.setInt(4, grade.getMaxSalary());
			
      
			int c2=pst2.executeUpdate();
			
			if(c2>0)
			{
				System.out.println("Record Inserted");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	

	private Connection getMysqlDbConnection() {
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "admin");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}


}
