package com.cap.service;

public class EmployeeServiceImpl implements IEmployeeService{

}
